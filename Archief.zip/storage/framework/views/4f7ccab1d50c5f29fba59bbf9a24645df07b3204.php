<?php $__env->startSection('page-title'); ?>
    30 seconds
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-src'); ?>
    /images/30seconds.png
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-alt'); ?>
    30 seconds banner
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-title'); ?>
    30 seconds
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-desc'); ?>
    Op deze pagina is meer te vinden over 30 seconds!
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-title'); ?>
    30 seconds
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-desc'); ?>
    Spectaculair partyspel voor teams. Fantastisch voor grote gezelschappen op feestjes en partijen. Je speelt in teams. Een van jullie probeert binnen 30 seconden zoveel mogelijk van de vijf begrippen op een kaartje te omschrijven. Hoe meer begrippen jullie raden, des te meer velden jullie op het speelbord vooruit mogen. Een dobbelsteenworp kan daar nog verandering in brengen. Welk team bereikt als eerste de finish? 30 Seconds, het uitdagende spel waarbij je snel moet denken en net zo snel moet praten, garandeert uren speelplezier met jouw familie en vrienden. Het wordt zeker supergezellig!
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar-title'); ?>
    Eigenschappen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user-icon'); ?>
    3/24
<?php $__env->stopSection(); ?>

<?php $__env->startSection('euro-icon'); ?>
    29,75
<?php $__env->stopSection(); ?>

<?php $__env->startSection('gamepad-icon'); ?>
    Partyspel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('birthday-icon'); ?>
    12-99
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stopwatch-icon'); ?>
    30m
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-picture-1'); ?>
    /images/30seconds-1.jpg
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-alt-1'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-picture-2'); ?>
    /images/30seconds-2.jpg
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-alt-2'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.games', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marijnboeve/Websites/Skills Heroes/spellen-winkel/resources/views/30seconds.blade.php ENDPATH**/ ?>