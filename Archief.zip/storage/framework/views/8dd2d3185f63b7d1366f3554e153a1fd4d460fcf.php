<?php $__env->startSection('page-title'); ?>
    Carcassone
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-src'); ?>
    /images/Carcassone.png
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-alt'); ?>
    Carcassone banner
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-title'); ?>
    Carcassone
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-desc'); ?>
    Op deze pagina is meer te vinden over Carcassone!
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-title'); ?>
    Carcassone
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-desc'); ?>
    In het bordspel Carcassonne is het Franse Carcassonne is de best behouden middeleeuwse vestingstad. De spelers zijn landheren en zetten hun horigen in om zoveel mogelijk invloed in het gebied te krijgen. Iedere beurt trek je een landtegel die je vervolgens aanlegt aan het steeds groter wordende speelveld. Op de zojuist gelegde tegel mag je vervolgens een horige als struikrover, ridder, monnik of boer plaatsen. Met die horigen, waarvan je er natuurlijk een beperkt aantal hebt, scoor je punten als hun weg, stad of klooster wordt afgebouwd. Ze komen dan terug in de voorraad en zijn direct opnieuw inzetbaar.

    <p>Lastig wordt het als andere spelers er door het slim plaatsen van landtegels voor zorgen dat je horigen geen mogelijkheden meer hebben om ooit nog in je voorraad terug te keren. Je zult dus goed moeten nadenken, hoe, wanneer en waar je de horigen inzet!</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar-title'); ?>
    Eigenschappen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('user-icon'); ?>
    2/5
<?php $__env->stopSection(); ?>

<?php $__env->startSection('euro-icon'); ?>
    24,95
<?php $__env->stopSection(); ?>

<?php $__env->startSection('gamepad-icon'); ?>
    Legspel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('birthday-icon'); ?>
    7-99
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stopwatch-icon'); ?>
    35m
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-picture-1'); ?>
    /images/carcassone-1.jpg
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-alt-1'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-picture-2'); ?>
    /images/carcassone-2.jpg
<?php $__env->stopSection(); ?>

<?php $__env->startSection('game-alt-2'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.games', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marijnboeve/Websites/Skills Heroes/spellen-winkel/resources/views/carcassone.blade.php ENDPATH**/ ?>